(function () {
  const KEY = "bcp-hackaton-2026:demo:v3";
  const clone = (o) => JSON.parse(JSON.stringify(o));

  function getState() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return Object.assign(clone(DEMO_DATA.seedState), JSON.parse(raw));
    } catch (e) {}
    return clone(DEMO_DATA.seedState);
  }

  function setState(patch) {
    const next = Object.assign(getState(), patch);
    localStorage.setItem(KEY, JSON.stringify(next));
    return next;
  }

  function resetState() {
    localStorage.removeItem(KEY);
  }

  window.DemoState = { getState, setState, resetState };

  if (new URLSearchParams(location.search).get("reset") === "1") {
    resetState();
    history.replaceState(null, "", location.pathname);
  }

  document.addEventListener("keydown", (e) => {
    const tag = (e.target.tagName || "").toLowerCase();
    if (e.key.toLowerCase() !== "r" || e.ctrlKey || e.metaKey || e.altKey) return;
    if (tag === "input" || tag === "textarea" || tag === "select" || e.target.isContentEditable) return;
    if (confirm("¿Reiniciar la demo al estado inicial?")) {
      resetState();
      location.reload();
    }
  });
})();
