(function () {
  const DURATION_MS = 250;

  // Muestra el spinner DURATION_MS y luego ejecuta la acción.
  function withSpinner(button, action) {
    if (button.disabled || button.classList.contains("is-loading")) return;
    button.classList.add("is-loading");
    button.disabled = true;
    setTimeout(() => {
      button.classList.remove("is-loading");
      button.disabled = false;
      action();
    }, DURATION_MS);
  }

  window.withSpinner = withSpinner;
})();
