window.DEMO_DATA = {
  project: { key: "NEUR", name: "NEUR" },
  issueType: "Story",
  statuses: ["To Do", "In Progress", "In Review", "Done"],
  labels: [
    "sdd-ready", "sdd-drafting", "sdd-awaiting-answers", "sdd-spec-review", "sdd-answers-provided",
    "sdd-spec-approved", "sdd-deps-analysis", "sdd-awaiting-deps-confirmation", "sdd-deps-confirmed",
    "sdd-completed", "sdd-blocked"
  ],
  firstIssueNumber: 1050,
  toastMs: 3000,
  specGeneratedDelayMs: 2000,
  // Cada fase espera un label manual (trigger) que dispara una automatización.
  // "after" son ms desde el paso anterior; "unlock" habilita texto y Grabar antes de terminar.
  phases: {
    draft: { trigger: "sdd-ready", automation: "ready", next: "awaiting-answers" },
    "awaiting-answers": { trigger: "sdd-answers-provided", automation: "answers", next: "spec-review" },
    "spec-review": { trigger: "sdd-spec-approved", automation: "approved", next: "awaiting-deps" },
    "awaiting-deps": { trigger: "sdd-deps-confirmed", automation: "depsConfirmed", next: "completed" }
  },
  automations: {
    ready: [
      { after: 2000, label: "sdd-drafting", unlock: true },
      { after: 1000, label: "sdd-awaiting-answers", content: "reviewed", fields: { criteria: "El usuario loggeado debe poder ver solo las cuentas asociadas a su tarjeta" }, toast: { title: "Story autocompletada", text: "Se autocompletó la Story. Debes revisarla." } }
    ],
    answers: [
      { after: 2000, label: "sdd-drafting" },
      { after: 2000, label: "sdd-spec-review", specification: true, toast: { title: "Especificación lista", text: "La especificación está lista para ser aprobada." } }
    ],
    approved: [
      { after: 2000, label: "sdd-deps-analysis" },
      { after: 2000, label: "sdd-awaiting-deps-confirmation", fields: { dependencies: "- Interconexión con core bancario SYSTEMATICS" }, toast: { title: "Dependencias identificadas", text: "Se identificaron dependencias. Debes confirmarlas." } }
    ],
    depsConfirmed: [
      { after: 2000, label: "sdd-completed", createSubtasks: true, toast: { title: "Subtareas creadas", text: "Se crearon las subtareas de la Story." } }
    ]
  },
  subtasks: [
    { key: "NEUR-1056", summary: "Generar formato FAE para conexión con Systematics" },
    { key: "NEUR-1059", summary: "Generar subscription key para API BS Card V4" },
    { key: "NEUR-1065", summary: "Crear Mirror Transaction" },
    { key: "NEUR-1089", summary: "Codificar consulta de cuentas y saldos en microservicio" },
    { key: "NEUR-2006", summary: "Implementar pantalla de consulta de cuentas" }
  ],
  issueDetails: {
    "NEUR-1089": {
      type: "Sub-task",
      status: "To Do",
      parent: { key: "NEUR-1050", summary: "Consultar saldo y crédito disponible de una tarjeta Visa" },
      repo: { name: "hybridcloudcompany/ms-cuentas-saldos", branch: "develop", url: "github-code.html" },
      sections: [
        {
          title: "Objetivo",
          paragraphs: ["Codificar en el microservicio de cuentas la consulta de cuentas y saldos asociados a la tarjeta del cliente autenticado, integrándola con el core bancario mediante la API BS Card V4."]
        },
        {
          title: "Alcance técnico",
          items: [
            "<strong>Validación del número de tarjeta:</strong> longitud, formato numérico y dígito verificador (algoritmo de Luhn) antes de cualquier invocación externa.",
            "<strong>Invocación de API externa:</strong> consumo del endpoint de consulta de cuentas de BS Card V4 con la subscription key vigente, timeout de 5 s y un reintento.",
            "<strong>Procesamiento del resultado:</strong> mapeo de la respuesta al modelo interno, filtrado de las cuentas del cliente autenticado y enmascarado del número de tarjeta.",
            "<strong>Manejo de errores:</strong> códigos de error funcionales y técnicos, mensajes controlados al canal y registro en logs sin datos sensibles."
          ]
        },
        {
          title: "Criterios de aceptación",
          items: [
            "Un número de tarjeta inválido es rechazado sin invocar a la API externa.",
            "El servicio devuelve únicamente las cuentas asociadas a la tarjeta del usuario autenticado.",
            "Ante timeout o error de la API externa, el servicio responde con un error controlado y deja trazabilidad en los logs.",
            "Los logs no contienen números de tarjeta completos ni datos sensibles.",
            "Pruebas unitarias con cobertura mínima del 80 % en la lógica nueva."
          ]
        },
        {
          title: "Dependencias",
          items: [
            "NEUR-1059 – Subscription key para API BS Card V4.",
            "NEUR-1056 – Formato FAE para conexión con Systematics."
          ]
        }
      ]
    }
  },
  flowText: {
    summary: "Consultar saldo y crédito disponible de una tarjeta Visa",
    description:
      "COMO cliente titular de una tarjeta de crédito Visa,\n" +
      "QUIERO consultar el saldo adeudado y el crédito disponible,\n" +
      "PARA conocer mi deuda y cuánto puedo utilizar en nuevas compras."
  },
  reviewedDescriptionHtml:
    "<strong>COMO</strong> cliente titular de una tarjeta de crédito Visa,\n" +
    "<strong>QUIERO</strong> consultar el saldo adeudado y el crédito disponible,\n" +
    "<strong>PARA</strong> conocer mi deuda y cuánto puedo utilizar en nuevas compras.\n" +
    "\n" +
    "PENDIENTES POR RESOLVER\n" +
    "- ¿el saldo se muestra en plano, o se ofusca y el usuario debe apretar un botón ojito?\n" +
    "- ¿debe mostrarse las cuentas bloqueadas?\n" +
    "- ¿debe mostrarse las cuentas mancomunadas?\n" +
    "- ¿debe mostrarse el número de cuenta en plano u ofuscado algunos caracteres?\n" +
    "\n" +
    "CRITERIOS DE SEGURIDAD\n" +
    "- Revisar impacto por norma <strong>PCI</strong> pues se usa números de tarjeta\n" +
    "- Asegurarse de ofuscar los logs por datos <strong>DAC</strong>",
  seedState: {
    draft: { summary: "", descriptionHtml: "" },
    labels: [],
    fields: { specification: "", criteria: "", dependencies: "" },
    status: "To Do",
    issue: null,
    phase: "draft",
    auto: null,
    subtasks: [],
    subtaskStatus: {}
  }
};
