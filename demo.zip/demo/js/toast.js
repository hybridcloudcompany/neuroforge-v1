(function () {
  const CHECK = '<svg class="toast-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-1.5 14.5-4-4 1.4-1.4 2.6 2.6 5.6-5.6 1.4 1.4z"/></svg>';
  let el = null;
  let timer = null;

  function hide() {
    clearTimeout(timer);
    if (el) el.hidden = true;
  }

  // Un solo toast a la vez; dura DEMO_DATA.toastMs y se puede cerrar con la X.
  window.showToast = function (title, text) {
    if (!el) {
      el = document.createElement("div");
      el.className = "toast";
      el.setAttribute("role", "status");
      document.body.appendChild(el);
    }
    el.innerHTML = CHECK +
      '<div><div class="toast-title"></div><div class="toast-text"></div></div>' +
      '<button class="toast-close" type="button" aria-label="Cerrar">&times;</button>';
    el.querySelector(".toast-title").textContent = title;
    el.querySelector(".toast-text").textContent = text || "";
    el.querySelector(".toast-close").addEventListener("click", hide);
    el.hidden = false;
    clearTimeout(timer);
    timer = setTimeout(hide, DEMO_DATA.toastMs);
  };
})();
