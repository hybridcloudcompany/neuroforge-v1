(function () {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const inline = (s) =>
    esc(s).replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");

  // Renderizador mínimo: títulos, listas, bloques de código, párrafos, negrita y código en línea.
  window.renderMarkdown = function (md) {
    const out = [];
    const lines = md.split("\n");
    let list = false;
    let code = false;
    const closeList = () => { if (list) { out.push("</ul>"); list = false; } };

    for (const line of lines) {
      if (line.startsWith("```")) {
        closeList();
        out.push(code ? "</code></pre>" : "<pre><code>");
        code = !code;
        continue;
      }
      if (code) { out.push(esc(line) + "\n"); continue; }
      const h = line.match(/^(#{1,4}) (.*)$/);
      if (h) { closeList(); out.push("<h" + h[1].length + ">" + inline(h[2]) + "</h" + h[1].length + ">"); continue; }
      if (line.startsWith("- ")) {
        if (!list) { out.push("<ul>"); list = true; }
        out.push("<li>" + inline(line.slice(2)) + "</li>");
        continue;
      }
      closeList();
      if (line.trim()) out.push("<p>" + inline(line) + "</p>");
    }
    closeList();
    return out.join("");
  };
})();
